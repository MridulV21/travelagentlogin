package com.example.travel_agent_login;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ActionRepository extends JpaRepository<Action, Long> {
	 @Query("SELECT a FROM Action a WHERE a.action = :actionDescription AND a.timestamp >= :recentTime")
	    List<Action> findRecentActions(@Param("actionDescription") String actionDescription, 
	                                   @Param("recentTime") LocalDateTime recentTime);
}
