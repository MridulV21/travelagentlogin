package com.example.travel_agent_login;

import java.util.List;

import org.openqa.selenium.By;

public class AirlineBookingFlow {
    private String airlineUrl;  // The URL for the airline booking page
    private List<By> actionsSequence;  // The list of steps or actions to perform

    public AirlineBookingFlow(String airlineUrl, List<By> actionsSequence) {
        this.airlineUrl = airlineUrl;  // Set the URL
        this.actionsSequence = actionsSequence;  // Set the steps
    }

    public String getAirlineUrl() {
        return airlineUrl;  // Get the URL
    }

    public List<By> getActionsSequence() {
        return actionsSequence;  // Get the list of steps
    }
}