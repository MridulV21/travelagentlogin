package com.example.travel_agent_login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class BookingController {

    @Autowired
    private SeleniumService_old seleniumService;

    //@GetMapping("/book/{airline}")
    public String viewAirlineActions(@PathVariable("airline") String airline, Model model) {
        // Get the logged actions for the selected airline
        model.addAttribute("airline", airline);
        //model.addAttribute("actions", actions);
        return "book";
    }
}