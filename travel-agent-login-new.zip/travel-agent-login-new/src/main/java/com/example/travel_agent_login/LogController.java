package com.example.travel_agent_login;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class LogController {

    @Autowired
    private ActionRepository actionRepository;

    @PostMapping("/log")
    public String logUserAction(@RequestBody UserActionLogRequest request) {
    	String actionDescription = request.getAction();
    	 int maxLength = 255;  // Set this to match the database column's length limit

    	    // Truncate if action description is too long
    	    if (actionDescription.length() > maxLength) {
    	        actionDescription = actionDescription.substring(0, maxLength - 3) + "...";
    	    }
        LocalDateTime recentTime = LocalDateTime.now().minusSeconds(2); 

        // Query recent entries with the same action
        List<Action> recentActions = actionRepository.findRecentActions(actionDescription, recentTime);
        
        if (recentActions.isEmpty()) {
    	Action action = new Action();
        action.setUsername("mridul");
        action.setAction(request.getAction());
        action.setTimestamp(LocalDateTime.now());

        actionRepository.save(action);
        }
        return "Action logged successfully";
    }
}