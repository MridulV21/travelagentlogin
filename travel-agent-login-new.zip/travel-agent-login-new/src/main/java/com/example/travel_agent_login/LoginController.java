package com.example.travel_agent_login;

import java.time.LocalDateTime;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {
	
	@Autowired
    private SeleniumService seleniumService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
    private ActionRepository actionRepository;
	
	  @GetMapping("/dashboard")
	    public String dashboard(Model model) {
	        // Add a list of airlines (hardcoded for now)
		  List<String> airlines = List.of("AirIndia", "Indigo", "SpiceJet");
	        model.addAttribute("airlines", airlines);
	        return "dashboard";
	    }
    @GetMapping("/login")
    public String login() {
        return "login"; // This will point to login.html
    }

    @PostMapping("/login")
    public String loginPost(@RequestParam String username, @RequestParam String password, Model model) {
        // Fetch the user from the database based on username
        User user = userRepository.findByUsername(username);

        // Validate if the user exists and the password matches
        if (user != null && user.getPassword().equals(password)) {
        	 // Log the successful login action
            logAction(username, "Logged in successfully");
            return "redirect:/dashboard"; // Redirect to dashboard on successful login
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "login"; // Return to login page if credentials are invalid
        }
    }
    
    private void logAction(String username, String actionDescription) {
        Action action = new Action();
        action.setUsername(username);
        action.setAction(actionDescription);
        action.setTimestamp(LocalDateTime.now());  // Set current time

        actionRepository.save(action);  // Save the action to the database
    }
    @GetMapping("/book/{airline}")
    public String book(@PathVariable String airline, Model model) throws InterruptedException {
        // Call Selenium service to perform the login
    	model.addAttribute("airline", airline);
    	seleniumService.autoLogin(airline);
        return "actions.html";
    }
    
    @GetMapping("/api/actions")
    @ResponseBody
    public List<Action> getActions() {
        return actionRepository.findAll();  // Fetch all actions from the database
    }
  }