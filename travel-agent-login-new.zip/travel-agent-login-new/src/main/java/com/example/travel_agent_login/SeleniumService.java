package com.example.travel_agent_login;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.function.Function;

import io.github.bonigarcia.wdm.WebDriverManager;

@Service
public class SeleniumService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
    private ActionRepository actionRepository;
		
	private WebDriver driver;
	private ScheduledExecutorService scheduler;
	private Set<String> existingWindows;
	    
	
	 public void autoLogin(String airline) throws InterruptedException {
		 // Initialize WebDriver, assuming ChromeDriver is set up correctly
		 
		 
		 WebDriverManager.chromedriver().setup();
		 
			/*
			 * WebDriverManager.firefoxdriver().setup(); FirefoxOptions options = new
			 * FirefoxOptions(); this.driver = new FirefoxDriver();
			 */
			    ChromeOptions options = new ChromeOptions(); 
			    //options.addArguments("--incognito"); 
			    options.addArguments("--start-maximized");
			    options.addArguments("--disable-blink-features=AutomationControlled");
			    options.addArguments("--disable-gpu");  // Use in cases where GPU issues arise
			    options.addArguments("--no-sandbox");   // Good for Linux
			    options.addArguments("--disable-dev-shm-usage"); // Good for memory management
			    options.addArguments("--disable-infobars");
			    options.addArguments("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
				System.setProperty("webdriver.chrome.logfile", "chromedriver.log");
		        System.setProperty("webdriver.chrome.verboseLogging", "true");
		        
		        this.driver = new ChromeDriver(options);
		        driver.manage().logs().get("driver").forEach(log -> System.out.println(log));
		        existingWindows = driver.getWindowHandles();
			 
			Thread.sleep(5000); 
		
			switch (airline.toLowerCase()) {
	            case "airindia":
	                loginToAirindia(airline);
	                break;
	            case "spicejet":
	                loginToSpiceJet(airline);
	                break;
	            case "indigo":
	                loginToIndigo(airline);
	                break;
	            default:
	                System.out.println("No automated login available for " + airline);
	                break;
	        }
			injectJavaScriptForUserActionLogging();
			//injectJavaScriptForBookingTracking();
			monitorAndReinjectJavaScriptOnPageLoad();
			monitorAndHandleNewTabs();
	    }
	
	  private void loginToAirindia(String airline) throws InterruptedException {
	        driver.get("https://www.airindiaexpress.com/home");
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//div[@class='header-sidebar']//div")).click();
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//input[@id='Partner']")).click();
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//input[@id='email-input-sso']")).sendKeys("APIINBLWRC_ADMIN");
	        driver.findElement(By.xpath("//input[@id='password-input-sso']")).sendKeys("Srrjklgh$611");
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
	        Thread.sleep(3000);
	        String currenttitle= driver.getTitle();
	        String expectedtitle= "Air India Express | Partner Homepage ";
	        Thread.sleep(3000);
	        if(currenttitle==expectedtitle) {
	        logAction(airline, "Logged in automatically to " + airline);
	        }
	        else {
	        logAction(airline, "Unable to log in to " + airline);	
	        }
	        
			/*
			 * scheduler = Executors.newScheduledThreadPool(1);
			 * scheduler.scheduleAtFixedRate(this::injectJavaScriptForUserActionLogging, 0,
			 * 20, TimeUnit.SECONDS);
			 */
	  }

	    private void loginToSpiceJet(String airline) throws InterruptedException {
	        driver.get("https://book.spicejet.com/LoginAgent.aspx");
	        logAction(airline, "Navigating to " + airline);
	    	
	        Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='ControlGroupLoginAgentView_AgentLoginView_TextBoxUserID']")).sendKeys("delbla3614");
			
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='ControlGroupLoginAgentView_AgentLoginView_PasswordFieldPassword']")).sendKeys("bal$%57IN86");
			
			Thread.sleep(3000);
			driver.findElement(By.xpath("//body/div[@id='loginAgent']/form[@id='SkySales']/div[@id='wrapper']/div[@class='innerbody']/div[@class='inner_right']/div[@id='mainContent']/div[@id='selectMainBody']/div[@class='agLoginTab']/div[@class='content']/div[@class='agent margin-top-36']/div[@class='margin-top-36']/div[@class='login']/div[@id='loginContent']/div[@class='loginContent-left']/div[@class='login-box']/div/div[@class='login-button-align']/input[1]")).click();
			driver.findElement(By.id("search-flight")).click();
            logAction(airline, "Clicked 'Search Flight' on " + airline);
            
            driver.findElement(By.id("book-now")).click();
            logAction(airline, "Logged into " + airline);
            
            driver.findElement(By.xpath("//span[@class='text-label'][normalize-space()='Manage Booking']")).click();
            logAction(airline, "Clicked 'Manage Bookings' on " + airline);

            driver.findElement(By.xpath("//input[@id='ControlGroupRetrieveBookingHomeView_BookingRetrieveInputRetrieveBookingHomeView_ConfirmationNumber']")).click();
            logAction(airline, "Clicked 'Book Now' on " + airline);
	    }

	    private void loginToIndigo(String airline) throws InterruptedException {
	    	 driver.get("https://www.google.com");
	    	    Thread.sleep(2000);
	    	   
	    }
	    
	    private void monitorAndHandleNewTabs() {
	        String originalWindow = driver.getWindowHandle();
	        //Set<String> existingWindows = driver.getWindowHandles();  
	        // Repeatedly check for new tabs or windows
	        new Thread(() -> {
	            while (true) {
	            	
	               Set<String> currentWindows = driver.getWindowHandles();
	                for (String windowHandle : currentWindows) {
	                    if (!existingWindows.contains(windowHandle)) {
	                        // Switch to new tab or window
	                        driver.switchTo().window(windowHandle);
	                        System.out.println("Switched to new tab: " + windowHandle);

	                        // Re-inject JavaScript for click tracking in new tab
	                        injectJavaScriptForUserActionLogging();

	                        // Update the existing windows set
	                        existingWindows = currentWindows;
	                    }
	                }

	                // Check for navigations in the same tab
	                if (!driver.getWindowHandle().equals(originalWindow)) {
	                    driver.switchTo().window(originalWindow);
	                    injectJavaScriptForUserActionLogging();
	                    //injectJavaScriptForBookingTracking();
	                }

	                try {
	                    Thread.sleep(1000); // Check every second
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }).start();
	    }
	    
	    private void monitorAndReinjectJavaScriptOnPageLoad() {
	        // Continuously check if a new page has loaded, then re-inject JavaScript
	        new Thread(() -> {
	            String lastUrl = driver.getCurrentUrl();

	            while (true) {
	                String currentUrl = driver.getCurrentUrl();

	                if (!currentUrl.equals(lastUrl)) { // URL change detected
	                    System.out.println("Detected navigation to new page: " + currentUrl);

	                    // Wait for the page to load completely
	                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	                    wait.until((Function<WebDriver, Boolean>) wd ->
	                            ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
	                    
	                    // Re-inject JavaScript for click tracking
	                    injectJavaScriptForUserActionLogging();
	                    //injectJavaScriptForBookingTracking();

	                    // Update lastUrl to the current page
	                    lastUrl = currentUrl;
	                }

	                try {
	                    Thread.sleep(500); // Check every 0.5 seconds
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }).start();
	    }
	    private void injectJavaScriptForUserActionLogging() {
	        if (driver instanceof JavascriptExecutor) {
	            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

	            String script = 
	                // Check if the script is already injected
	                "if (!window.scriptInjected) {" +
	                "    window.scriptInjected = true;" +  // Set the flag to prevent reinjection
	                "    console.log('Starting Manage button tracking');" +
	                "    setTimeout(function() {" +

	                "        document.querySelectorAll('.tc-b2b-wrapper').forEach(function(wrapper, index) {" +
	                "            console.log('Wrapper found at index:', index);" +

	                "            var radioButton = wrapper.querySelector('.tc-b2b-radio input[type=\"radio\"]');" +
	                "            var pnrElement = null;" +

	                "            wrapper.querySelectorAll('.tc-b2b-data div').forEach(function(div) {" +
	                "                var text = div.innerText.trim();" +
	                "                if (/^[A-Z0-9]{6}$/.test(text)) {" +
	                "                    console.log('PNR detected:', text);" +
	                "                    pnrElement = div;" +
	                "                }" +
	                "            });" +

	                "            if (radioButton && pnrElement) {" +
	                "                radioButton.addEventListener('click', function() {" +
	                "                    window.selectedPNR = pnrElement.innerText.trim();" +
	                "                    console.log('PNR selected:', window.selectedPNR);" +
	                "                });" +
	                "            }" +
	                "        });" +

	                "        var manageButton = document.querySelector('.b2b-mb-action-banner .default_view button:nth-child(2)');" +
	                "        if (manageButton) {" +
	                "            manageButton.addEventListener('click', function() {" +
	                "                if (window.selectedPNR) {" +
	                "                    var logMessage = 'Agent is Editing booking with PNR: ' + window.selectedPNR;" +
	                "                    console.log(logMessage);" +

	                "                    fetch('http://localhost:8080/api/log', {" +
	                "                        method: 'POST'," +
	                "                        headers: { 'Content-Type': 'application/json' }," +
	                "                        body: JSON.stringify({ action: logMessage })" +
	                "                    }).then(response => {" +
	                "                        if (response.ok) {" +
	                "                            console.log('Log sent successfully:', logMessage);" +
	                "                        } else {" +
	                "                            console.error('Failed to send log:', response.statusText);" +
	                "                        }" +
	                "                    }).catch(error => console.error('Error in log fetch request:', error));" +
	                "                } else {" +
	                "                    console.log('No PNR selected');" +
	                "                }" +
	                "            });" +
	                "            console.log('Manage button event listener added');" +
	                "        } else {" +
	                "            console.log('Manage button not found');" +
	                "        }" +

	                "    }, 3000);" +
	                "} else {" +
	                "    console.log('Script already injected, skipping execution');" +
	                "}";

	            jsExecutor.executeScript(script);
	            System.out.println("JavaScript injected with execution flag check.");
	        }
	    }

		     
		private void logAction(String airline,String actionDescription) {
	        Action action = new Action();
	        action.setUsername("mridul"); 
	        action.setAction(actionDescription);
	        action.setTimestamp(LocalDateTime.now());

	        actionRepository.save(action);  
	  	}
    
}
