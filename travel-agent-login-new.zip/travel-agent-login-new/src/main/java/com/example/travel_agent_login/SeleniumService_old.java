package com.example.travel_agent_login;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.github.bonigarcia.wdm.WebDriverManager;

@Service
public class SeleniumService_old {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
    private ActionRepository actionRepository;
	
    public String autoLogin(String airline) {
        // Set the path for the ChromeDriver
    	WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
		WebDriver driver = new ChromeDriver();
		try {
			Thread.sleep(5000);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://book.spicejet.com/LoginAgent.aspx");
			logAction(airline, "Navigating to " + airline);
			/*
			 * Thread.sleep(7000);
			 * driver.findElement(By.xpath("//span[@id='flight-close']")).click();
			 */
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='ControlGroupLoginAgentView_AgentLoginView_TextBoxUserID']")).sendKeys("delbla3614");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='ControlGroupLoginAgentView_AgentLoginView_PasswordFieldPassword']")).sendKeys("bal$%57IN86");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//body/div[@id='loginAgent']/form[@id='SkySales']/div[@id='wrapper']/div[@class='innerbody']/div[@class='inner_right']/div[@id='mainContent']/div[@id='selectMainBody']/div[@class='agLoginTab']/div[@class='content']/div[@class='agent margin-top-36']/div[@class='margin-top-36']/div[@class='login']/div[@id='loginContent']/div[@class='loginContent-left']/div[@class='login-box']/div/div[@class='login-button-align']/input[1]")).click();
			driver.findElement(By.id("search-flight")).click();
            logAction(airline, "Clicked 'Search Flight' on " + airline);
            driver.findElement(By.id("book-now")).click();
            logAction(airline, "Logged into " + airline);
            
            driver.findElement(By.xpath("//span[@class='text-label'][normalize-space()='Manage Booking']")).click();
            logAction(airline, "Clicked 'Manage Bookings' on " + airline);

            driver.findElement(By.xpath("//input[@id='ControlGroupRetrieveBookingHomeView_BookingRetrieveInputRetrieveBookingHomeView_ConfirmationNumber']")).click();
            logAction(airline, "Clicked 'Book Now' on " + airline);
            
			return "Logged in Successfully!";
		} catch (Exception e) {
			return "Error occurred while executing Selenium script: " + e.getMessage();
		}
    }
		private void logAction(String airline,String actionDescription) {
	        Action action = new Action();
	        action.setUsername("mridul"); 
	        action.setAction(actionDescription);
	        action.setTimestamp(LocalDateTime.now());

	        actionRepository.save(action);  
	  	}
    
  
    
  //span[@class='text-label'][normalize-space()='Manage Booking']
  //input[@id='ControlGroupRetrieveBookingHomeView_BookingRetrieveInputRetrieveBookingHomeView_ConfirmationNumber']
  //input[@id='ControlGroupRetrieveBookingHomeView_BookingRetrieveInputRetrieveBookingHomeView_CONTACTEMAIL1']
}
