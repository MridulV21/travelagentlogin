package com.example.travel_agent_login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAgentLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelAgentLoginApplication.class, args);
	}

}
