package com.example.travel_agent_login;


public class UserActionLogRequest {
    private String action;

    // Getter and Setter
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
