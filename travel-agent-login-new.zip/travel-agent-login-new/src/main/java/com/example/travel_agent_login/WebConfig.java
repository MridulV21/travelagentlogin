package com.example.travel_agent_login;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig {
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/log") // Map the /api/log endpoint
                        .allowedOrigins("*")    // Allow all origins for testing; specify your domain in production
                        .allowedMethods("POST") // Allow POST requests only
                        .allowedHeaders("*");   // Allow all headers for testing
            }
        };
    }
}
