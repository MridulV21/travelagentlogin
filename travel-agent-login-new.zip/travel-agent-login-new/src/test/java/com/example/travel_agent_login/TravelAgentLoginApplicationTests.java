package com.example.travel_agent_login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelAgentLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
